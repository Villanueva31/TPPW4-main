//Chiedo all'utente 2 numeri 
let num1 = Number( window.prompt("Inserisci un numero") );
let num2 = Number( window.prompt("Inserisci un altro numero") );

console.log("Primo numero " + num1 + " - secondo numero " + num2);

let somma = num1  +  num2 ;
console.log("La somma vale: " + somma);

let moltiplicazione = num1 * num2;
let sottrazione = num1 - num2;
let divisione = num1 / num2;

console.log("La moltiplicazione vale: " + moltiplicazione);
console.log("La sottrazione vale: " + sottrazione);
console.log("La divisione vale: " + divisione);

