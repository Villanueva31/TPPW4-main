//STRING
let frase = "Oggi è la nostra seconda lezione";

//stampo la stringa in console
console.log(frase);

//Voglio stampare il tipo della frase
console.log(typeof frase); //string


//NUMBER
let oraDelGiorno = 14;

let piuTardi = oraDelGiorno + 5;

console.log("tra 5 ore saranno le: " + piuTardi);
console.log(typeof oraDelGiorno); //number


//BOOLEAN
let presenza = true;

console.log("Lo studente è presente ? " + presenza);
console.log(typeof presenza); //boolean 
