export class Studente{
    constructor(public id: number, public nome: string, public corso: string){
    }
}