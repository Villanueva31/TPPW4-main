export class Docente{
    constructor(public id: number, public nome: string, public materia: string, public corso: string){
    }
}