import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-utenti',
  templateUrl: './utenti.component.html',
  styleUrls: ['./utenti.component.css']
})
export class UtentiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
