//Operatori di confronto

let num1 = 2;
let num2 = 5;

let cond1 = (num1 == num2); //False
console.log(cond1);

let cond2 = (num1 != num2); //True

let cond3 = (num1 > num2); //F
let cond4 = (num1 < num2); //T

let cond5 = (num1 >= num2); //F
let cond6 = (num1 <= num2); //T


let num3 = "10";
let num4 = 10;

let cond7 = (num3 == num4); //T
let cond8 = (num3 === num4); //F

let cond9 = (num3 != num4); //F
let cond10 = (num3 !== num4); //T

//operatore NOT logico
let luceAccesa = true;
console.log(!luceAccesa); //false



