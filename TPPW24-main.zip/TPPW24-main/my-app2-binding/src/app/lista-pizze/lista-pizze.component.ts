import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-pizze',
  templateUrl: './lista-pizze.component.html',
  styleUrls: ['./lista-pizze.component.css']
})
export class ListaPizzeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
