export class Pizza{
    constructor(public nome:string, public prezzo: number){
        
    }
}