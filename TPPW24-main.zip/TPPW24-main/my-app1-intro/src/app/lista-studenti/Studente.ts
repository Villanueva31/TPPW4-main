export interface Studente{
    nome: string,
    cognome: string
}