//Crea un elenco di 400 numeri random. (ATT: puoi anche svolgere soolo la parte del controllo del numero)Per ogni numero dire se questo si trova tra 20 e 100 oppure tra 20 e 400.

let numero = 75; //questo numero si trova tra 20 e 100

let numero2 = 112; //questo numero si trova tra 20 e 400



