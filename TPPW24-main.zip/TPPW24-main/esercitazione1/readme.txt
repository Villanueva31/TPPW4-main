PRIMA PARTE

ES1 Scrivi, utilizzando if-statement, un programma per trovare il numero più grande tra 5 numeri in un array. Mostra il risultato in console.

Es2 Scrivi un loop che itera da 0 a 15. Per ogni ciclo controlla se il numero è pari o dispari. Mostra il risultato in console. if(numero % 2 == 0){il numero è pari}

Es3 Scrivi un programma che itera tutti i numeri interi da 1 a 100. Per i multipli di 3 stamperà “Zoom” mentre per i multipli di 5 stamperà “Boom”. Controlla anche il caso in cui il numero è divisibile sia per 3 sia per 5 stampando “Zoom Boom”.

Es4-1 Scrivi un programma per replicare il seguente pattern. Dato l'array [4, 2, 6]:
* * * *
* *
* * * * * * 

Es4 Scrivi un programma per costruire il seguente pattern.
*  
* *  
* * *  
* * * *  
* * * * *

Es5 Scrivi un programma che somma i multipli di 3 e multipli di 5 sotto il numero 1000. ris: 233168

Es.6
Scrivi un programma che stampa un pattern come il seguente triangolo, chiedendo all’utente il numero di righe:
1
12
123
1234
12345

Es.7
Scrivi un programma che stampa il seguente pattern :
1
2 3
4 5 6
7 8 9 10

Es.8
Scrivi un programma che stampa il seguente pattern con un numero di righe variabile:
@
@@
@@@
@@@@
@@@@@
@@@@@@

PARTE 2

ES1 Scrivi una funzione javascript che accetti due argomenti, una stringa e una lettera. La funzione conterà il numero di occorrenze della specifica lettera nella stringa

Es2 Scrivi una funzione javascript che accetta un “argomento” e ritorna il tipo di dato: oggetto, funzione, stringa, numero, undefined.

Es3 Scrivi una funzione javascript che accetta una stringa come parametro e trova la parola più lunga all’interno della frase. Es (mi chiamo Massimiliano -> Massimiliano).

Es4 Dall’html recupera una stringa e ruotala da sinistra verso destra rimuovendo una lettera dal fondo ed inserendola all’inizio, deve essere visibile l’animazione. 

Es5 Scrivi un programma che accetta (da input) un numero come input e inserisce un dash (-) tra due numeri pari. Es ( 823486 -> 8-234-8-6 )

Es6 Scrivi un programma per inserire degli elementi in un array vuoto e farli stampare quando viene premuto un bottone 

Es7 Scrivi una funzione javascript che rimuova gli elementi duplicati da un array.

Es8 Dati due array, calcolare la somma degli elementi presenti nello stesso indice. Esempio:
array1 = [1,0,2,4,6]
array2 = [0,4,5,8,7]
Output = [1,4,7,12,13]

Es9 Scrivi una funzione che unisca due array rimuovendo gli elementi in comune.
