//JAVASCRIPT è debolmente tipizzato, cioè non ho l'obbligo di dichiarare il tipo ma il linguaggio sa perfettamente di cosa parlo

// HO Dichiarato una variabile e gli ho assegnato un valore di tipo String

let cognome = "Mennillo"; //String
let eta = 34;  //Number
let presenza = true;  //Boolean

//dichiaro una variabile
let coloreMaglia;

//assegno un valore
coloreMaglia = "verde";

let citta = "Torino";
var cittaDiNascita = "Napoli"; //var è obsoleto

//STAMPO il valore di una variabile in console
console.log(nome);
console.log(cognome);

console.log(nome + " " + cognome);

let a = 1;
let b = 2;
let somma = a + b;
console.log("La somma di 1 e 2 vale " + somma );

let c = "6";
let d = "5";
console.log(c + d); //è qui il problema
console.log(c * d);
