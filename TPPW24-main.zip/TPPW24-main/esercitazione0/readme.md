# Esercitazione 0
1. Costruire l'alberatura di base (struttura cartelle)
2. Collegare bene i file html e js
3. Nel js, inserire una descrizione di se stessi attraverso l'uso delle seguenti variabili:
    - Nome
    - Cognome
    - Città 
    - Anno di Nascita
    - Età (calcolata attraverso l'anno di nascita)

4. Stampa ogni singola variabile in console
5. Stampa una descrizione completa usando tutte le variabili