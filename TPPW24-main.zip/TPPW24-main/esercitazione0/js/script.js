//creo le mie variabili
let nome = "Dario";
let cognome = "Mennillo";
let citta = "Torino";
let annoNascita = 1989;

let eta = 2023 - annoNascita;

console.log(nome);
console.log(cognome);
console.log(citta);
console.log(annoNascita);
console.log(eta);

let descrizioneCompleta = "Mi chiamo " + nome + " " + cognome + " e ho " + eta + " anni. Vivo a " + citta;

console.log(descrizioneCompleta);