export class Server{
    constructor(public nome: string,public tipo: string,public status: boolean){}
}